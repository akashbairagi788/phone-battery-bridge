Phone Battery Bridge — Android Studio project

এই অ্যাপটি ফোনের ব্যাটারি শতাংশ এবং চার্জিং অবস্থা BLE দিয়ে ESP32-S3-এ পাঠানোর জন্য।

গুরুত্বপূর্ণ:
- এই প্রজেক্টটি Android Studio-তে খুলে Build > Build APK(s) ব্যবহার করে APK বানাতে হবে।
- ফোন ও ESP32-তে Bluetooth চালু রাখুন।
- অ্যাপে ESP32 BLE নাম দিন: Weather-ESP32
- Start চাপুন এবং Bluetooth/Notification permission অনুমতি দিন।
- Android-এর Battery settings থেকে অ্যাপের জন্য Unrestricted / Don't optimize নির্বাচন করলে স্ক্রিন বন্ধ অবস্থায় চালু থাকার সম্ভাবনা বাড়ে।
- প্রতি ১০ সেকেন্ডে BLE characteristic-এ UTF-8 text পাঠায়: "85,1"
  প্রথম সংখ্যা = ব্যাটারি শতাংশ (0–100)
  দ্বিতীয় সংখ্যা = charging flag (1=charging/full, 0=not charging)

ESP32-S3 BLE firmware-এ নিচের UUID একই রাখতে হবে:
Service:        7b2e0001-7a5d-4f6b-9c3a-1234567890ab
Characteristic: 7b2e0002-7a5d-4f6b-9c3a-1234567890ab

এই Android অ্যাপ একা চালালেই TFT-তে কিছু দেখাবে না; ESP32-S3 firmware-এ একই BLE service/characteristic তৈরি করে পাঠানো ডেটা পড়তে হবে।
