package com.example.phonebatterybridge

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var deviceName: EditText
    private val requestCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

        layout.addView(label("PHONE BATTERY BRIDGE", 22f))
        layout.addView(label("Phone battery → ESP32-S3 Weather Display", 14f, 0xFFB8C7D1.toInt()))
        layout.addView(Space(this).apply { minimumHeight = 24 })
        status = label("Status: Not connected", 18f, 0xFF55DDA0.toInt())
        layout.addView(status)
        layout.addView(Space(this).apply { minimumHeight = 16 })
        layout.addView(label("ESP32 BLE device name", 14f, 0xFFB8C7D1.toInt()))
        deviceName = EditText(this).apply {
            setSingleLine()
            setText("Weather-ESP32")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AAAB5.toInt())
        }
        layout.addView(deviceName)
        val start = Button(this).apply {
            text = "Start sending battery"
            setOnClickListener { checkAndStart() }
        }
        layout.addView(start)
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, BatteryBleService::class.java))
                status.text = "Status: Stopped"
            }
        }
        layout.addView(stop)
        layout.addView(Space(this).apply { minimumHeight = 18 })
        layout.addView(label("Keep the notification active while sending. On some phones, allow background activity / unrestricted battery use.", 13f, 0xFFB8C7D1.toInt()))
        setContentView(layout)
        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN
            p += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        val missing = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), requestCode)
    }

    private fun checkAndStart() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Turn Bluetooth on, then press Start."
            return
        }
        val name = deviceName.text.toString().trim().ifEmpty { "Weather-ESP32" }
        val intent = Intent(this, BatteryBleService::class.java).putExtra("device_name", name)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Status: Searching for $name…"
    }
}
