package com.example.phonebatterybridge

import android.Manifest
import android.app.*
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.UUID

class BatteryBleService : Service() {
    companion object {
        // Must match the UUIDs in the ESP32-S3 BLE firmware.
        val SERVICE_UUID: UUID = UUID.fromString("7b2e0001-7a5d-4f6b-9c3a-1234567890ab")
        val BATTERY_UUID: UUID = UUID.fromString("7b2e0002-7a5d-4f6b-9c3a-1234567890ab")
        private const val CHANNEL_ID = "battery_bridge"
        private const val NOTIFICATION_ID = 7
    }

    private val handler = Handler(Looper.getMainLooper())
    private var scanner: android.bluetooth.le.BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var characteristic: BluetoothGattCharacteristic? = null
    private var targetName = "Weather-ESP32"
    private var connected = false
    private var lastScanAt = 0L

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        targetName = intent?.getStringExtra("device_name") ?: targetName
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("Looking for $targetName"))
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        scanner = adapter?.bluetoothLeScanner
        beginScan()
        handler.removeCallbacks(sender)
        handler.post(sender)
        return START_STICKY
    }

    private fun beginScan() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("Bluetooth scan permission missing")
            return
        }
        try {
            scanner?.startScan(scanCallback)
            lastScanAt = System.currentTimeMillis()
            updateNotification("Scanning for $targetName")
        } catch (_: SecurityException) {
            updateNotification("Bluetooth permission missing")
        }
    }

    private val scanCallback = object : android.bluetooth.le.ScanCallback() {
        override fun onScanResult(callbackType: Int, result: android.bluetooth.le.ScanResult) {
            val device = result.device
            try {
                if (device.name == targetName && gatt == null) {
                    scanner?.stopScan(this)
                    updateNotification("Connecting to $targetName")
                    gatt = device.connectGatt(this@BatteryBleService, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                }
            } catch (_: SecurityException) { updateNotification("Bluetooth permission missing") }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connected = true
                updateNotification("Connected to $targetName")
                try { g.discoverServices() } catch (_: SecurityException) {}
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                characteristic = null
                g.close()
                if (gatt === g) gatt = null
                handler.postDelayed({ beginScan() }, 3000)
                updateNotification("Disconnected; reconnecting")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val service = g.getService(SERVICE_UUID)
            characteristic = service?.getCharacteristic(BATTERY_UUID)
            updateNotification(if (characteristic != null) "Connected; sending battery" else "Connected, but BLE characteristic not found")
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) { }
    }

    private val sender = object : Runnable {
        override fun run() {
            if (connected && characteristic != null) {
                val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val percent = if (level >= 0 && scale > 0) (level * 100 / scale).coerceIn(0, 100) else 0
                val charging = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) in
                    listOf(BatteryManager.BATTERY_STATUS_CHARGING, BatteryManager.BATTERY_STATUS_FULL)
                val payload = "$percent,${if (charging) 1 else 0}".toByteArray(Charsets.UTF_8)
                try {
                    if (Build.VERSION.SDK_INT >= 33) {
                        gatt?.writeCharacteristic(characteristic!!, payload, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
                    } else {
                        @Suppress("DEPRECATION")
                        characteristic!!.value = payload
                        @Suppress("DEPRECATION")
                        characteristic!!.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                        @Suppress("DEPRECATION")
                        gatt?.writeCharacteristic(characteristic)
                    }
                } catch (_: Exception) { }
            }
            handler.postDelayed(this, 10000)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Battery bridge", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(message: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Phone Battery Bridge")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        handler.removeCallbacks(sender)
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        super.onDestroy()
    }
}
